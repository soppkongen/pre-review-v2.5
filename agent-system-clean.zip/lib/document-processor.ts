// Dummy processor, since your actual PDF handling is elsewhere
export async function extractTextFromDocument(file: any): Promise<string> {
  // Replace with actual logic later
  return 'Dummy document content';
}
