export interface AgentResult {
  agentName: string;
  insights: string[];
}
